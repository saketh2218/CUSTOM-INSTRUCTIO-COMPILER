from lexical_analysis import parse_input
from syntax_analysis import parse_expression
from semantic_analysis import semantic_check, evaluate_expression
from intermediate_code import generate_intermediate_code
from code_generation import generate_final_result

def main():
    input_file = "input.txt"
    output_file = "output.txt"

    # Lexical Analysis - Parse input
    values = parse_input(input_file)

    # Syntax Analysis - Build AST
    ast = parse_expression(values)

    # Semantic Check (placeholder)
    semantic_check(values)

    # Generate Intermediate Code (Three Address Code)
    intermediate_code = generate_intermediate_code(ast)

    # Evaluate Final Result
    result = generate_final_result(ast)

    # Write output to file
    with open(output_file, "w") as f:
        f.write("TOKENS:\n")
        for k, v in values.items():
            f.write(f"  {k} = {v}\n")
        f.write("\nINTERMEDIATE CODE (TAC):\n")
        for line in intermediate_code:
            f.write(f"  {line}\n")
        f.write("\nRESULT:\n")
        f.write(f"  {result}\n")

if __name__ == "__main__":
    main()