def semantic_check(values):
    # Placeholder semantic checks (could add type checks etc.)
    return True

def evaluate_expression(ast):
    if 'value' in ast:
        return ast['value']
    elif 'var' in ast:
        return ast['value']
    elif ast['op'] == '+':
        return evaluate_expression(ast['left']) + evaluate_expression(ast['right'])
    elif ast['op'] == '*':
        return evaluate_expression(ast['left']) * evaluate_expression(ast['right'])