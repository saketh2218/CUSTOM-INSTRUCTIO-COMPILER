def parse_expression(values):
    # Builds AST for (A * B) + (C * D) + E
    return {
        'op': '+',
        'left': {
            'op': '*',
            'left': {'var': 'A', 'value': values['A']},
            'right': {'var': 'B', 'value': values['B']}
        },
        'right': {
            'op': '+',
            'left': {
                'op': '*',
                'left': {'var': 'C', 'value': values['C']},
                'right': {'var': 'D', 'value': values['D']}
            },
            'right': {'var': 'E', 'value': values['E']}
        }
    }