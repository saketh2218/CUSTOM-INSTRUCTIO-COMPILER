from syntax_analysis import parse_expression
from semantic_analysis import evaluate_expression
from intermediate_code import generate_intermediate_code
from code_generation import generate_final_result

# Sample token values
tokens = {
    'A': 4.0,
    'B': 5.0,
    'C': 2.0,
    'D': 2.0,
    'E': 3.0
}

# Expression: (A * B) + (C * D) + E
expression = "(A * B) + (C * D) + E"

print("TOKENS:")
for var, val in tokens.items():
    print(f"  {var} = {val}")

# Parse
ast = parse_expression(tokens)

# Generate TAC
tac = generate_intermediate_code(ast)
print("\nINTERMEDIATE CODE (TAC):")
for line in tac:
    print(f"  {line}")

# Final Result using semantic evaluation
result = evaluate_expression(ast)
print("\nRESULT:")
print(f"  {result}")