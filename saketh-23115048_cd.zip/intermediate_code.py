def generate_intermediate_code(ast):
    code = []
    temp_count = 1

    def helper(node):
        nonlocal temp_count
        if 'value' in node:
            return str(node['value'])
        elif 'var' in node:
            return node['var']
        else:
            left = helper(node['left'])
            right = helper(node['right'])
            temp = f"t{temp_count}"
            temp_count += 1
            code.append(f"{temp} = {left} {node['op']} {right}")
            return temp

    helper(ast)
    return code