def generate_final_result(ast):
    if 'value' in ast:
        return ast['value']
    elif 'var' in ast:
        return ast['value']
    elif ast['op'] == '+':
        return generate_final_result(ast['left']) + generate_final_result(ast['right'])
    elif ast['op'] == '*':
        return generate_final_result(ast['left']) * generate_final_result(ast['right'])